void random_array(char *array, long bytes);
int get_histogram(FILE *, long *, int , long *, long *);
