# The script is running on my own machine (Macbook pro 2016) and my own USB
# drive (Kingston 8GB)
import os
import numpy as np
import pylab as pl
import argparse
from subprocess import check_output

parser = argparse.ArgumentParser()
parser.add_argument("-m", "--medium", default='hdd', choices=["hdd", "ssd", "usb"], metavar="['hdd', 'ssd', 'usb']", help="set the storage medium")
parser.add_argument("-t", "--total_bytes", type=int, default=100, help="set the total size for the file (unit: MBytes)")
args = parser.parse_args()
total_bytes = args.total_bytes * 1024 * 1024
block_sizes = [128]*30 + [1024]*30 + [4096]*30 + [8192]*30  + [65536]*30  + [131072]*30  + [524288]*30  + [1048576]*30  + [2097152]*30  + [3145728]*30 
if args.medium == "hdd" or args.medium == "ssd":
    file_names = ["block_size_" + str(block_size) + "B" + str(index) + ".txt" for index, block_size in enumerate(block_sizes)]
elif args.medium == "usb":
    usb_path = "/Volumes/x/CSC443/"
    file_names = [usb_path + "block_size_" + str(block_size) + "B" + str(index) + ".txt" for index, block_size in enumerate(block_sizes)]

write_data_rates = [0] * 300
read_data_rates = [0] * 300
for i in range(300):
    # calculate write data rates
    write_result = check_output(["./create_random_file", file_names[i], str(total_bytes), str(block_sizes[i])])
    write_result = write_result.split()[1]
    write_data_rates[i] = int(total_bytes / (float(write_result) / 1000))

for i in range(300):
    # calculate read data rates
    read_result = check_output(["./get_histogram", file_names[i], str(block_sizes[i])])
    read_result = read_result.splitlines()[-1].split()[1]
    read_data_rates[i] = int(total_bytes / (float(read_result) / 1000))

# Write Plot
# use pylab to plot x and y
pl.plot(block_sizes, write_data_rates, 'ro', ms=3)
# give plot a title
pl.title('Write Data Rate Versus Block Size')
# make axis labels
pl.xlabel('Block Size (Byte)')
pl.ylabel('Write Data Rates (Byte/Second)')
# set discontinous points
pl.xscale('log')
# show the plot on the screen
if args.medium == "hdd" or args.medium == "ssd":
    pl.savefig('sequential_write.png', bbox_inches='tight')
elif args.medium == "usb":
    usb_path = "/Volumes/x/CSC443/"
    pl.savefig(usb_path + 'sequential_write.png', bbox_inches='tight')
# pl.show()

pl.close()

# Read Plot
# use pylab to plot x and y
pl.plot(block_sizes, read_data_rates, 'ro', ms=3)
# give plot a title
pl.title('Read Data Rate Versus Block Size')
# make axis labels
pl.xlabel('Block Size (Byte)')
pl.ylabel('Read Data Rates (Byte/Second)')
# set discontinous points
pl.xscale('log')
# show the plot on the screen
if args.medium == "hdd" or args.medium == "ssd":
    pl.savefig('sequential_read.png', bbox_inches='tight')
elif args.medium == "usb":
    usb_path = "/Volumes/x/CSC443/"
    pl.savefig(usb_path + 'sequential_read.png', bbox_inches='tight')
# pl.show()
